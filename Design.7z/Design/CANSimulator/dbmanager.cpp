#include "dbmanager.h"

DbManager::DbManager()
{
}
