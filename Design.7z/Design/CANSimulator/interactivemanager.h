#ifndef INTERACTIVEMANAGER_H
#define INTERACTIVEMANAGER_H

#include <QMainWindow>

namespace Ui {
class InteractiveManager;
}

class InteractiveManager : public QMainWindow
{
    Q_OBJECT

public:
    explicit InteractiveManager(QWidget *parent = 0);
    ~InteractiveManager();

private:
    Ui::InteractiveManager *ui;
};

#endif // INTERACTIVEMANAGER_H
