#include "mainsimulator.h"
#include <QApplication>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QFile>
#include <QFileDialog>
#include <QObject>
#include <stdint.h>
#include <stdint-gcc.h>
#include <limits.h>
#include <float.h>
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    MainSimulator w;
    w.show();
//    long double v = 1.84467E+20;
//    qDebug() << sizeof( long double ) << DBL_MAX << (1.8446744e+19 > DBL_MAX) ;

//    QFileDialog * fileDialog = new QFileDialog();
//    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Create new database file"), QDir::currentPath(), ("Database files (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
//    if(!fileName.isEmpty()){
//        QFile file(fileName);
//        qDebug() << "open" << file.open(QIODevice::ReadOnly | QIODevice::WriteOnly | QIODevice::Text);
//    //    file.reset();
////        qDebug() << "File content" << file.readAll();
//#if 1
////        QJsonObject jsonObject,jsonObject2;
////        QJsonDocument jsonDoc = QJsonDocument::fromJson(QString(file.readAll()).toUtf8());
////        qDebug() << jsonDoc.toJson();
////        jsonObject =jsonDoc.object() ;
////        QJsonValueRef value = jsonObject["MMMM"];
////        jsonObject2.insert("hello",2);
////        jsonObject.insert("MMMM",1);
////        jsonDoc.setObject(jsonObject);
////        file.resize(0);
////        file.write(jsonDoc.toJson());
//        QVariantMap map;
//        map.insert("integer", 1);
//        map.insert("double", 2.34);
//        map.insert("bool", QVariant(true));
//        map.insert("string", "word");
//        QJsonObject object,object2;

//        object = QJsonObject::fromVariantMap(map);
//        object2.insert("TEST",QJsonValue(object));
////        QVariantMap map2;
//        QJsonDocument document;
////        map2.insert("test",QVariant(object));
//        document.setObject(object2);
//    qDebug() << document.toJson();
//#else
//        jsonObject["hello"] = 1;
//        QJsonObject jsonObjectM ;
//        jsonObjectM["MMMM"] = jsonObject;
//        QJsonDocument jsonDoc(jsonObjectM);

//        qDebug() << "Example of QJsonDocument::toJson() >>>";
//        qDebug() << jsonDoc.toJson();
//        file.resize(0);
//        file.write(jsonDoc.toJson());
//#endif
////        qDebug() << "<<<";
//        file.close();

//    }



    return a.exec();
}
